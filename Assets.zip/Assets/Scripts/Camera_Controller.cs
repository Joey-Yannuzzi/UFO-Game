﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera_Controller : MonoBehaviour {

    public GameObject player; //creates private data for player GameObject

    private Vector3 offset; //Creates vector3 value

	// Use this for initialization
	void Start () {

        offset = transform.position - player.transform.position; //value dtores the difference between player and camera
	}
	
	// Update is called once per frame
	void LateUpdate () // Runs only after previous update is finished
    {

        transform.position = player.transform.position + offset; //sets new camera position
	}
}