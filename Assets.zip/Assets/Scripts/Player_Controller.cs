﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player_Controller : MonoBehaviour {

    private Rigidbody2D rb2d; //Creates private variable for the RigidBody2D component
    public float speed; // creates an addition to script component to change player's speed
    private int score; //creates a variable to store the number of pickups collected
    public Text score_text; //creates text variable to display score
    public Text win; //creates the text to dislay win

    private void Start() //Method that activates when the game starts
    {
        win.text = "";
        rb2d = GetComponent<Rigidbody2D>(); //Gives variable connection to the Rigidbody2D component
        score = 0; //sets the score to 0 when the game starts
        Set_Score_Text();
    }

    private void FixedUpdate() //Updates game for every physics calculation preformed
    {
        float horizontal, vertical; //Creates 2 float variables

        horizontal = Input.GetAxis("Horizontal"); //Assigns float horizontal to horizontal axis on keyboard
        vertical = Input.GetAxis("Vertical"); //Assigns float vertical to vertical axis on keyboard

        Vector2 move = new Vector2(horizontal, vertical); //creates Vector2 to store the x/y values for moving the player

        rb2d.AddForce(move * speed); //adds movement/speed to the player
    }

    void OnTriggerEnter2D(Collider2D other) //Activates when player collides with an object
    {
        if (other.gameObject.CompareTag ("Pickup")) //checks if collided object is tagged under Pickup
        {
            other.gameObject.SetActive (false); // if the tag is Pickup the object is set to false
            score = score + 1; //adds a point to the score when a pickup is collected
            Set_Score_Text();
        }
    }

    void Set_Score_Text()
    {
        score_text.text = "Score: " + score.ToString(); // sets display when the score is updated

        if (score >= 12)
        {
            win.text = "You Win!!!";
        }
    }
}