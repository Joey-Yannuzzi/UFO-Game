Use Arrowkeys to move
My first game crrated
Game created by Joey Yannuzzi